Instruction:
Run executable with: $ ./executable
Output will be stored in file predictions.txt

Predictions used for coda lab stored in predictions.csv and predictions.zip